import React from "react";

const CreateAccount = () => {
  return <div>CreateAccount</div>;
};

export default CreateAccount;
